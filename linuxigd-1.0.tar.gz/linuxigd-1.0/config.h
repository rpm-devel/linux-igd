#ifndef _CONFIG_H_
#define _CONFIG_H_

int parseConfigFile(globals_p vars);

#endif // _CONFIG_H_
